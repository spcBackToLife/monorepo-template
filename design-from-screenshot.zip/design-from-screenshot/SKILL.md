---
name: design-from-screenshot
description: 按照用户提供的参考设计截图/设计稿，使用 MCP 设计工具（canvas/style/element/material）精确还原或创建素材/页面组件。当用户提供 UI 设计参考图并要求实现/还原/绘制时触发。支持场景：按钮、卡片、图标、插画、渐变背景、页面布局等视觉元素的从图还原。
---

# 截图还素材设计 Skill

根据用户提供的参考设计图（截图/设计稿），使用 MCP 设计工具链精确还原视觉设计。

## 何时使用此技能

- 用户上传参考截图要求还原/复刻某个 UI 组件
- 用户要求按设计稿创建按钮、卡片、图标、插画等素材
- 用户要求修复现有页面使其匹配参考图样式
- 用户要求用画布工具绘制特定图形效果

## 核心工作流

严格遵循以下四阶段流程，**不可跳过任何阶段**：

---

### Phase 1: 分析参考图（必须最先完成）

拿到用户给的参考图后，**不要立即调用任何 MCP 工具**，先做完整分析并输出分析报告。

#### 1.1 视觉层次拆解

从截图中逐层识别元素，画出结构树：

```
根容器
├── 背景层（颜色/图片/渐变）
├── 主容器（卡片/面板）
│   ├── 文字区（标题/副标题/描述）
│   ├── 操作区（按钮组）
│   └── 辅助区（分页点/指示器/图标）
└── 装饰层（阴影/光效/纹理 - 如有）
```

**逐个记录每个可见元素：**
- 元素类型（div / button / text / image / path / 图形）
- 层级关系（父子嵌套）
- 布局方式（flex 行/列、绝对定位、居中、space-between）
- 大致位置（上/中/下/左/右）

#### 1.2 提取样式参数

对每个元素提取可量化的样式值：

| 参数 | 分析方法 | 记录格式 |
|------|---------|---------|
| 颜色 | 判断色相+明度，记近似 hex | `#a855f7` 或 `rgba(255,255,255,0.85)` |
| 渐变 | 方向 + 起止色 | `linear-gradient(135deg, #a855f7, #f97316)` |
| 圆角 | 目测 px 值：小(4-8) / 中(12-16) / 大(20-32) | `borderRadius: 24` |
| 内边距 | 相对字号的倍数 | `padding: 24px 20px` |
| 外边距 | 元素间间距 | `marginBottom: 16` |
| 字号 | 标题(20-28) / 正文(14-16) / 辅助(11-13) | `fontSize: 14` |
| 字重 | Regular(400) / Medium(500) / Semibold(600) / Bold(700) | `fontWeight: 700` |
| 阴影 | 模糊半径 + 扩散 + 偏移 | `boxShadow: 0 4px 20px rgba(0,0,0,0.15)` |
| 尺寸比例 | 宽高比或占容器百分比 | `width: 100%` 或 `height: 46` |

> **注意**：不确定的参数标注为估算值（如 `~12px`），后续可通过截图迭代微调。

#### 1.3 选择 MCP 工具组合

根据设计类型选择合适的工具：

| 设计目标 | 推荐工具 | 说明 |
|---------|---------|------|
| 画图形/图标/插画 | `canvas` add_object | rect/ellipse/path/star/textbox/image |
| 修改已有页面元素样式 | `style` update/batch_update | CSS 样式批量修改 |
| 新增/删除/调整 DOM 节点 | `element` add/remove/move/wrap | HTML 结构操作 |
| 导出素材并应用到节点 | `canvas` export_and_apply | 画布→设计节点的桥梁 |
| 生成渐变/阴影/动画 CSS | `canvas` generate_*_css | 辅助计算 CSS 代码 |
| 修改文字内容 | `component_prop` update_props | 设置 textContent（**不是 children!**） |

**重要规则**：
- 操作**已有页面元素** → 用 `style` + `element`
- **从零画新素材** → 用 `canvas` add_object 系列
- 画完后要应用到节点 → 用 `export_and_apply`
- 文字必须用 `textContent` 而非 `children`（渲染器只读 textContent）

---

### Phase 2: 制定执行方案

完成分析后，输出结构化的执行方案，**等用户确认后再执行**：

```markdown
## 执行方案

### 步骤 1: [简述]
- 工具: canvas / action: add_object
- 参数:
  - type: rect, x: ..., y: ..., width: ..., height: ...
  - fill: linear-gradient(...)
  - rx: 24
- 目标: 创建圆角渐变背景卡片

### 步骤 2: [简述]
- 工具: element / action: add
- 参数:
  - parent: <父节点ID>
  - tag: p
  - props.textContent: "标题文字"
- 目标: 添加标题文本

...（依次列出所有步骤）
```

**方案要求**：
- 步骤之间有依赖的标明顺序
- 可并行执行的步骤归为一组
- 每个参数都有从图中推导的来源说明

---

### Phase 3: 分步执行

按照确认的方案逐步执行，遵循以下规则：

#### 3.1 画布坐标系（使用 canvas 工具时必读）

**每次使用 canvas add_object/update_object 前，必须先调用 `get_canvas_info` 获取坐标信息！**

关键坐标概念：
- `referenceFrameWidth/Height`: 参考框尺寸（如 280×56）
- `referenceFrameX/Y`: 参考框在前端画布中的位置偏移
- add_object 的 x/y = **前端大画布坐标** = referenceFrameX/Y + 局部偏移
- 不要把 schema 里读到的大画布坐标直接传给 add_object！

正确流程：
```
1. get_canvas_info → 获取 rfx, rfy, refW, refH
2. add_object 时: { x: rfx + localX, y: rfy + localY }
```

#### 3.2 并行执行原则

- 无依赖的操作**同一批次并行调用**
- 有依赖的操作**串行等待**
- 同一工具的多个更新优先用 batch_update

#### 3.3 文字渲染规则（踩坑记录）

**渲染器 PrimitiveRenderer 只读 `props.textContent` 和 `props.text`，完全忽略 `props.children`！**

创建/修改文字节点时：
```javascript
// 正确 ✓
{ action: "update_props", props: { "textContent": "Hello World" } }

// 错误 ✗ — 文字不会显示!
{ props: { children: "Hello World" } }
```

适用元素：`p`, `h1`, `h2`, `span`, `button`, `label` 等所有文本容器。

#### 3.4 样式覆盖陷阱

默认样式可能包含 `minWidth: 40px`, `minHeight: 40px`, `width: fit-content` 等，
这些会导致：
- 圆形按钮变成椭圆
- 小元素被撑大
- 宽度不符合预期

修复方法：显式设置 `minHeight: auto`, `minWidth: auto`, `width: <期望值>`。

---

### Phase 4: 验证与迭代

每轮修改后必须验证：

1. **生成截图**: `generate_snapshots` 查看当前效果
2. **对比参考图**: 逐项检查差异
3. **列出差异清单**:
   ```
   - [ ] 背景色偏差
   - [ ] 卡片圆角不够
   - [ ] 字体偏大 2px
   - [ ] 按钮位置应在分页点下方（顺序反了）
   ```
4. **针对性修复**: 只修有差异的部分，不动已正确的部分
5. **循环**直到差异在可接受范围

## 常见问题速查

| 问题 | 原因 | 解决 |
|------|------|------|
| 文字不显示 | 用了 children 而非 textContent | 改用 component_prop update_props 设置 textContent |
| 元素被撑大 | 默认 minWidth/minHeight 40px | 显式设为 auto |
| 圆角不生效 | 默认样式覆盖或 borderRadius 格式错误 | 用 batch_update 强制设置 |
| 元素位置飞出画布 | 坐标系混淆（局部 vs 大画布） | 先 get_canvas_info 再算坐标 |
| 页面白屏崩溃 | BoxInput value.replace 报错 | 已修复（加了 typeof 检查） |
| export 后无效果 | 没建 material-slot 槽位 | 优先用 export_and_apply 自动建槽位 |

## 参考

详细的 MCP 工具参数规范见 `references/mcp-tool-guide.md`。
