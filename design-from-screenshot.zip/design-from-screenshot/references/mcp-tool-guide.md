# MCP 设计工具参数速查

> 本文件为 `design-from-screenshot` skill 的配套参考资料。当需要确认工具的具体参数格式时查阅。

## 1. canvas 工具 — 画布绘图

### get_canvas_info（必须首先调用）

```
action: get_canvas_info
参数: { projectId, materialId }
返回:
  - frontendCanvasWidth/Height: 前端画布总尺寸
  - referenceFrameWidth/Height: 参考框尺寸
  - referenceFrameX/Y: 参考框偏移量（add_object 坐标基准）
```

### add_object（添加图形）

```
action: add_object
必需参数:
  - type: rect | ellipse | polygon | star | path | line | textbox | image
  - x: Number（前端画布坐标 = rfx + 局部x）
  - y: Number（前端画布坐标 = rfy + 局部y）
可选参数（按类型选用）:
  - width / height: 尺寸（rect/ellipse/textbox/image）
  - fill: 填充色（#hex 或 CSS gradient 字符串）
  - stroke: 描边色（推荐: #1a3ab4 #32c896 #333333 #d4389a）
  - strokeWidth: 描边宽度
  - rx / ry: 圆角（仅 rect）
  - opacity: 透明度 (0~1)
  - rotation: 旋转角度
  - pathData: SVG 路径 d 属性（仅 path）
  - src: 图片 URL（仅 image）
  - x1 / y1 / x2 / y2: 端点坐标（仅 line）
```

### update_object（更新图形属性）

```
action: update_object
参数: { objectId, ...任意 add_object 的样式属性 }
用途: 修改已添加对象的位置、颜色、大小等
```

### export_and_apply（导出 PNG 并应用到设计节点）

```
action: export_and_apply
必需参数:
  - projectId: 项目 ID
  - materialId: 素材工程 ID（注意不是 materialProjectId）
  - nodeId: 目标设计节点 ID（必须！否则无法应用）
流程: get_schema → 裁剪渲染 → PNG → 上传 → applyMaterialDesign → 写入槽位
注意事项:
  - 导出尺寸 = referenceFrame 宽×高
  - 建议背景设为 transparent 避免白底
  - 自动处理 material-slot 槽位绑定
  - cssTarget 决定写 backgroundImage 还是 border-image
```

### generate_gradient_css / generate_shadow_cs

渐变和阴影的辅助生成工具，返回标准 CSS 字符串，可直接用于 fill 或 style 参数。

## 2. style 工具 — 样式修改

### update（单节点更新）
参数: `{ nodeId, projectId, styles: { ...CSS属性 } }`

### batch_update（多节点批量更新）
参数: `{ projectId, updates: [{ nodeId, styles }, ...] }`
推荐用于一次修改多个节点的样式。

## 3. element 工具 — DOM 结构操作

### add（添加元素）
```
action: add
参数:
  - parentNodeId: 父节点
  - tag: div | button | img | input | p | h1 | span 等 HTML 标签
  - props: { textContent: "文字内容" } ← 文字必须用 textContent！
  - initialStyles: 初始 CSS（可选）
```

### remove / move / duplicate / wrap / unwrap
基础 CRUD 操作，操作节点树结构。

### change_type
改变 HTML 标签类型（如 div → img）。

### reorder
调整元素在父节点中的排列顺序。

## 4. component_prop 工具 — 属性与文字

### update_props（关键：文字渲染必用）

**这是唯一能正确设置文字内容的方式。**

```javascript
// 设置/更新文字内容
{
  action: "update_props",
  nodeId: "nd_xxx",
  props: {
    "textContent": "要显示的文字"
  }
}
```

⚠️ 踩坑记录：
- 渲染器 PrimitiveRenderer.tsx 只读 `props.textContent` 和 `props.text`
- `props.children` 会被完全忽略，导致文字不显示
- 所有文本型元素（p/h1/h2/span/button）都必须用此方式设置文字

## 5. 其他工具速查

| 工具 | 常用 action | 场景 |
|------|------------|------|
| query | screen_schema / list_screens / project_info | 查看页面结构 |
| viewport | switch_viewport | 切换设备尺寸预览 |
| generate_snapshots | (无 action) | 生成截图验证效果 |
| visual_state | add / update / set_active | 组件状态管理（hover/disabled 等） |
| event | add_event / add_navigation | 交互事件绑定 |
| material_slot | create / list_by_node | 素材槽位管理 |

## 常用颜色参考

| 用途 | 颜色值 |
|------|--------|
| 主色调蓝 | #1677ff / #1a3ab4 |
| 成功绿 | #32c896 |
| 危险红 | #d4389a |
| 深色文字 | #333333 / #1a1a1a |
| 浅色文字 | rgba(255,255,255,0.85) |
| 半透明遮罩 | rgba(0,0,0,0.3~0.6) |
| 白色半透明按钮 | rgba(255,255,255,0.2~0.3) |
